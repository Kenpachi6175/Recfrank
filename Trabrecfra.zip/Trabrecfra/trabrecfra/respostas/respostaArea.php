<?php
                                require_once "../bancoDados/BDcadastrarArea.php";
                        
                                
                                $nomearea = $_POST["nomearea"];
                                $area = $_POST["area"];
                                
                            
                        
                                echo "<br>nomearea: \n<br>".$nomearea;
                                echo "<br>area: \n<br>".$area;
                                
                                cadastrar($nomearea, $area);
                                ?>     