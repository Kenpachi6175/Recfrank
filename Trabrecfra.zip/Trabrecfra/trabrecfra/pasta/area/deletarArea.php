<html>
    <body>
    <form method="post" action="deletarArea.php">
                                
                                
                                <p>Digite o nome:
                                <p> <input type="text" name="nomearea" required><br></p> <br>
                                </p>


                                <input type="submit" value="Executar">
                                </form>
    </body>
</html>
<?php

                                // Definir informações do banco de dados
                                $host = 'localhost';
                                $user = 'root';
                                $password = '';
                                $database = 'alefe2';
                                
                                // Conectar-se ao banco de dados
                                $conn = new mysqli($host, $user, $password, $database);
                                
                                
                                $nomearea = $_POST['nomearea']; 
                              

                                  // Fazer uma consulta SQL
                                  $query = "SELECT *
                                    FROM area
                                    WHERE area.nomearea = '$nomearea';";
                                  $result = $conn->query($query);


                                  // Verificar se o nome foi encontrado
                                  if ($result->num_rows > 0) {
                                    $row = $result->fetch_assoc();
                                    $query ="DELETE FROM area WHERE nomearea = '$nomearea'";
                                      $result = $conn -> query($query); 
                                      echo("informações deletadas com sucesso!");     
                                 }

                                    
                                
                                else {
                                   
                                    echo 'nome area não encontrado.';
                                  }
                                
                                
                                // Fechar conexão com o banco de dados
                                $conn->close();
                                
                                
                                ?>