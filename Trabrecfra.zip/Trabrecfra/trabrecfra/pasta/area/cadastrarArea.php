

<html>
    <body>
        <form  action="../../respostas/respostaArea.php" method="post">
<h1>CADASTRE-SE: </h1><br><p>
            <p>Nome: <input type="text" name="nomearea" required><br></p>
            <p>area: <input type="text" name="area" required><br></p>
            

            <input type="submit">
        </form>
    </body>   
</html>  
                    