<html>
    <body>
        <form  action="../../respostas/respostaCampus.php" method="post">
<h1>CADASTRE-SE: </h1><br><p>
            <p>Nome: <input type="text" name="nomecampus" required><br></p>
            
            <p>CEP: <input type="text" name="cep"required><br></p>
   

            <input type="submit">
        </form>
    </body>  
</html> 