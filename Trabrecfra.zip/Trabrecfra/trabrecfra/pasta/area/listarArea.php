<html>
    <body>
        <form  action="listarArea.php" method="post">
<h1>PROCURE UMA AREA: </h1><br><p>
            <p>Nome: <input type="text" name="nomearea" required><br></p>
            
           

            <input type="submit">
        </form>
    </body>
</html><?php
                                $host = 'localhost';
                                $user = 'root';
                                $password = '';
                                $database = 'alefe2';
                                
                                
                                $conn = new mysqli($host, $user, $password, $database);
                                
                                
                                $nomearea = $_POST['nomearea']; 

                                 
                                  $query = "SELECT *
                                    FROM area
                                    WHERE area.nomearea = '$nomearea';";
                                  $result = $conn->query($query);


                                  
                                  if ($result->num_rows > 0) {
                                    $query ="SELECT *
                                    FROM area
                                    WHERE area.nomearea = '$nomearea';";
                                  
                                    $result = $conn -> query($query);
                                    ?> <table >
                                    <thead>
                                    <tr>
                                    <th>    /nome da area/  </th>
                                    <th>    /area/  </th>
                                   
                                    
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php while ($row = $result->fetch_assoc()) { ?>
                                    <tr>
                                    <td>     <?php echo $row["nomearea"]; ?>     </td>
                                    <td>     <?php echo $row["area"]; ?>     </td>

                                     
                                    <td>
                                    
                                     
                                    </td>
                                    </tr>
                                    <?php } ?>
                                    </tbody>
                                    </table>
                                    <?php
                                    }
                                    
                                    else {
                                    echo 'nome não encontrado.';
                                    }
                                
                                $conn->close();
?>