<?php

function conectar()
{
    $pdo = new PDO("mysql:host=localhost;dbname=alefe2", "root", "");
    return $pdo;
}
function cadastrar($nomecampus, $cep)
{
    $pdo = conectar();
    $stmt = $pdo->prepare("INSERT INTO campus(nomecampus, cep) VALUES(?, ?)");
    $stmt->bindParam(1, $nomecampus);
    $stmt->bindParam(2, $cep);
    $stmt->execute();
}

?>