<html>
    <body>
        <form  action="listarCurso.php" method="post">
<h1>PROCURE UM CURSO: </h1><br><p>
            <p>Nome: <input type="text" name="nomecurso" required><br></p>
            
           

            <input type="submit">
        </form>
    </body>
</html><?php 
                                $host = 'localhost';
                                $user = 'root';
                                $password = '';
                                $database = 'alefe2';
                                
                                
                                $conn = new mysqli($host, $user, $password, $database);
                                
                                
                                $nomecurso = $_POST['nomecurso']; 

                                 
                                  $query = "SELECT *
                                    FROM curso
                                    WHERE curso.nomecurso = '$nomecurso';";
                                  $result = $conn->query($query);


                                  
                                  if ($result->num_rows > 0) {
                                    $query ="SELECT *
                                    FROM curso
                                    WHERE curso.nomecurso = '$nomecurso';";
                                    
                                    $result = $conn -> query($query);
                                    ?> <table >
                                    <thead>
                                    <tr>
                                    <th>    /nome curso/    </th>
                                    <th>    /areacurso/    </th>
                                    <th>    /campuscurso/    </th>
                                    <th>    /nota/    </th>
                                   
                                    
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php while ($row = $result->fetch_assoc()) { ?>
                                    <tr>
                                    <td>     <?php echo $row["nomecurso"]; ?>     </td>
                                    <td>     <?php echo $row["areacurso"]; ?>     </td>
                                    <td>     <?php echo $row["campuscurso"]; ?>     </td>
                                    <td>     <?php echo $row["nota"]; ?>     </td>

                                    
                                    <td>
                                    
                                     
                                    </td>
                                    </tr>
                                    <?php } ?>
                                    </tbody>
                                    </table>
                                    <?php
                                    }
                                    else {
                                    echo 'nome não encontrado.';
                                    }
                                
                                $conn->close();
?>