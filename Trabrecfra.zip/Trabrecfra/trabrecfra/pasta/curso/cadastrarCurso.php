<html>
    <body>
        <form  action="../../respostas/respostaCurso.php" method="post">
<h1>CADASTRE-SE: </h1><br><p>
            <p>Nome: <input type="text" name="nomecurso" required><br></p>
            <p>area: <input type="text" name="areacurso" required><br></p>
            <p>campus: <input type="text" name="campuscurso" required><br></p>
            <p>nota: <input type="tex" name="nota"required><br></p>
            

            <input type="submit">
        </form>
    </body> 
</html>