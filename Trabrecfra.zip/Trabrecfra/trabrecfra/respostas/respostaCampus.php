<?php
                                require_once "../bancoDados/BDcadastrarCampus.php";
                        
                                
                                $nomecampus = $_POST["nomecampus"];
                                $cep = $_POST["cep"];
                                
                                echo "<br>nome do campus: \n<br>".$nomecampus;
                                echo "<br>cep: \n<br>".$cep;

                                cadastrar($nomecampus, $cep);
                                ?> 